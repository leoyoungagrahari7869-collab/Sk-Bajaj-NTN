SK BAJAJ — HTML ADMIN PANEL (Hindi Guide)

FILES:
- index.html: public website
- admin.html: private editing tool (password-protected nahi hai)
- bikes.json: website ki bike list

SETUP (GitHub Pages):
1. GitHub repo Sk-Bajaj-NTN kholo.
2. index.html, admin.html aur bikes.json tino ko repo ke root (main folder) mein upload/replace karo.
3. Website: https://leoyoungagrahari7869-collab.github.io/Sk-Bajaj-NTN/
4. Admin: https://leoyoungagrahari7869-collab.github.io/Sk-Bajaj-NTN/admin.html
5. Admin page kholo. Bike edit/add/delete karo.
6. Download bikes.json dabao.
7. GitHub repo mein purani bikes.json ko nayi downloaded file se replace karo. Website update ho jayegi.

IMPORTANT:
- Ye pure HTML/JavaScript static workflow hai. Changes local admin page mein turant save hote hain, lekin public website tab update hoti hai jab nayi bikes.json GitHub par upload hoti hai.
- Admin page mein login/password security nahi hai. Isliye admin.html ka link public share mat karo; static HTML mein secure private admin login possible nahi hota.
- Photo upload karne par photo bikes.json mein embed hoti hai; file badi ho sakti hai. Compressed JPG/WebP use karein.
- Agar admin page ko direct file:// se kholne par inventory load na ho, Import bikes.json button se file load karein.
