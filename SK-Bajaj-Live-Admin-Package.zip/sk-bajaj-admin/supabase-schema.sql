-- Run this entire file in Supabase Dashboard > SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'viewer' check (role in ('admin','viewer')),
  created_at timestamptz not null default now()
);
create table if not exists public.motorcycles (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  variant text not null default '',
  category text not null default 'Motorcycle',
  price text not null default '',
  engine text not null default '',
  power text not null default '',
  torque text not null default '',
  gearbox text not null default '',
  brakes text not null default '',
  mileage text not null default '',
  capacity text not null default '',
  colors text not null default '',
  features text not null default '',
  image_url text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.motorcycles enable row level security;
-- Users can read only their own role row. No public profile enumeration.
create policy "read own profile" on public.profiles for select to authenticated using (id = auth.uid());
-- Public website visitors can read active inventory only.
create policy "public reads active bikes" on public.motorcycles for select to anon, authenticated using (is_active = true);
-- Only a profile explicitly assigned admin can manage inventory.
create policy "admins manage bikes" on public.motorcycles for all to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));
-- Storage: public image reads, admin-only uploads/updates/deletes.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('bike-photos','bike-photos',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true, file_size_limit=5242880, allowed_mime_types=array['image/jpeg','image/png','image/webp'];
create policy "public reads bike photos" on storage.objects for select to anon, authenticated using (bucket_id = 'bike-photos');
create policy "admins upload bike photos" on storage.objects for insert to authenticated with check (bucket_id = 'bike-photos' and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'));
create policy "admins update bike photos" on storage.objects for update to authenticated using (bucket_id = 'bike-photos' and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin')) with check (bucket_id = 'bike-photos' and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'));
create policy "admins delete bike photos" on storage.objects for delete to authenticated using (bucket_id = 'bike-photos' and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'));
