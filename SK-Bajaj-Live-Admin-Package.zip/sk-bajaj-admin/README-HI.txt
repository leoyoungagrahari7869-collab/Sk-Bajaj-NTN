SK BAJAJ — LIVE WEBSITE + SECURE ADMIN (Hindi)

FILES
- index.html: public website, reads active bikes from Supabase after setup.
- admin.html: private admin sign-in and bike management (add/edit/delete/photo upload).
- supabase-schema.sql: tables, Row Level Security and photo bucket policies.

SETUP
1) Create a project at https://supabase.com
2) Dashboard > SQL Editor > New query; paste all of supabase-schema.sql; Run.
3) Dashboard > Authentication > Users > Add user. Create your admin email/password.
4) Copy that user's UUID. In SQL Editor run:
   insert into public.profiles (id, role) values ('YOUR-USER-UUID', 'admin')
   on conflict (id) do update set role='admin';
   Replace YOUR-USER-UUID with the exact UUID.
5) Project Settings > API: copy Project URL and anon/publishable key.
6) Open BOTH index.html and admin.html in a text editor. In each file replace:
   YOUR_SUPABASE_PROJECT_URL with Project URL
   YOUR_SUPABASE_ANON_KEY with anon/publishable key
   Use only anon/publishable key. NEVER use service_role/secret key.
7) Upload index.html and admin.html to the ROOT of the existing GitHub Pages repository. Keep existing assets if any. Commit changes.
8) Admin URL: https://leoyoungagrahari7869-collab.github.io/Sk-Bajaj-NTN/admin.html
   Public URL: https://leoyoungagrahari7869-collab.github.io/Sk-Bajaj-NTN/
9) Login with the admin email/password created in step 3. Add a bike, enter details and upload photo.
10) Refresh public website. It will show active bikes from Supabase.

SECURITY
- Admin password is handled by Supabase Auth, not embedded in source.
- RLS policies restrict inventory changes and image uploads to profiles.role='admin'.
- Public visitors can only read active motorcycles and public bike photos.
- Do not publish Supabase service_role/secret key. Anon/publishable key is designed for browser use with RLS.

IMPORTANT
- Before Supabase is configured or if there are no rows yet, the public page continues to show its built-in bike list.
- Once there is at least one active database row, public inventory is sourced from Supabase. To make every existing bike manageable in Admin, add them once using Admin panel.
- Keep bike photos under 5 MB (JPG/PNG/WebP).
